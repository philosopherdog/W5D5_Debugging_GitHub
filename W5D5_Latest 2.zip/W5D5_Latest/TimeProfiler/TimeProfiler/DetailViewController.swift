//
//  DetailViewController.swift
//  TimeProfiler
//
//  Created by steve on 2016-05-29.
//  Copyright © 2016 steve. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

}
