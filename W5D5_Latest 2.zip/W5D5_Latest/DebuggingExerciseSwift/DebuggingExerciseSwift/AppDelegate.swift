//
//  AppDelegate.swift
//  DebuggingExerciseSwift
//
//  Created by steve on 2016-04-14.
//  Copyright © 2016 steve. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        
        // creates some dummy data
        let dummyData = UIFont.familyNames()
        
        let nav = self.window?.rootViewController as! UINavigationController
        let viewController = nav.topViewController as! ViewController
        viewController.data = dummyData
        return true
    }
}

