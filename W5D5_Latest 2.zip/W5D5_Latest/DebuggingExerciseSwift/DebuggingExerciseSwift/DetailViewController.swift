//
//  DetailViewController.swift
//  DebuggingExerciseSwift
//
//  Created by steve on 2016-04-14.
//  Copyright © 2016 steve. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {
    
    @IBOutlet weak var label: UILabel!
    
    var dataForRow:String!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.label.text = dataForRow
        self.label.font = UIFont(name: dataForRow, size: 22)
        self.label.sizeToFit()
        self.label.textColor = UIColor.randomColor()
    }
}
